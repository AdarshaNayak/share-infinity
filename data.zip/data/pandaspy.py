import sys
import os
import pandas as pd 

s = pd.Series([1, 3, 5, np.nan, 6, 8])
print(s)
print("import statements read from a file")